import os


import django



# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from decimal import Decimal
from main_app.models import Product
# Create a Product instance
product = Product.objects.create(name="Gaming Keyboard", price=Decimal(100.00))

# Calculate and print the tax
tax_price = product.calculate_tax()
print(f"Tax for {product.name}: ${tax_price:.2f}")

# Calculate and print the shipping cost
shipping_cost = product.calculate_shipping_cost(Decimal(2.50))
print(f"Shipping Cost for {product.name}: ${shipping_cost:.2f}")

# Format and print the product name
formatted_name = product.format_product_name()
print(f"Formatted Product Name: {formatted_name}")
