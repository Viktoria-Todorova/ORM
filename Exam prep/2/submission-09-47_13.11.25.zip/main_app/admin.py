from django.contrib import admin

from main_app.models import Director, Actor, Movie


# Register your models here.

@admin.register(Director)
class DirectorAdmin(admin.ModelAdmin):
    list_display = ['full_name','birth_date','nationality']
    filter = ['years_of_experience']
    search_fields = ['full_name','nationality']

@admin.register(Actor)
class ActorAdmin(admin.ModelAdmin):
    list_display = ['full_name','birth_date','nationality']
    filter = ['is_awarded']
    search_fields = ['full_name']
    readonly_fields = ['last_updated']

@admin.register(Movie)
class MovieAdmin(admin.ModelAdmin):
    list_display = ['title','storyline','rating','director']
    filter = ['is_awarded','is_classis','genre']
    search_fields = ['title','director__full_name']
    readonly_fields = ['last_updated']

